import Hero from "@components/Hero";

export default function Home() {
  return (
    <section className="relative z-10 pb-16 md:pb-[120px] xl:pb-[140px] 2xl:pb-[160px]">
      <Hero />
    </section>
  );
}
