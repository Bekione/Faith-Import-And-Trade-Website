
const HomeEssences = () => {
  return (
    <div>HomeEssences</div>
  )
}

export default HomeEssences