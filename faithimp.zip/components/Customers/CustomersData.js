export const customersData = [
  {
    id: "img001",
    path: "/images/customers/customer-1.avif",
    title: "Global Green Growth Institute",
  },
  {
    id: "img002",
    path: "/images/customers/customer-2.avif",
    title: "Center for International Private Enterprise",
  },
  {
    id: "img003",
    path: "/images/customers/customer-3.avif",
    title: "GIZ",
  },
  {
    id: "img004",
    path: "/images/customers/customer-4.avif",
    title: "GOAL Global",
  },
  {
    id: "img005",
    path: "/images/customers/customer-1.avif",
    title: "Global Green Growth Institute",
  },
  {
    id: "img006",
    path: "/images/customers/customer-2.avif",
    title: "Center for International Private Enterprise",
  },
  {
    id: "img007",
    path: "/images/customers/customer-3.avif",
    title: "GIZ",
  },
  {
    id: "img008",
    path: "/images/customers/customer-4.avif",
    title: "GOAL Global",
  },
  {
    id: "img009",
    path: "/images/customers/customer-1.avif",
    title: "Global Green Growth Institute",
  },
  {
    id: "img010",
    path: "/images/customers/customer-2.avif",
    title: "Center for International Private Enterprise",
  },
];
