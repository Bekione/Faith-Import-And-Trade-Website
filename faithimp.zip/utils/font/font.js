import localFont from "next/font/local"

export const mokoto = localFont({ src: "./mokoto.regular.ttf" })
